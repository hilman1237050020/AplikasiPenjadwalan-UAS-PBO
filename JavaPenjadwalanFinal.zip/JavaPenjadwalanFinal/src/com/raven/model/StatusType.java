package com.raven.model;

public enum StatusType {
    PENDING, APPROVED, REJECT
}
